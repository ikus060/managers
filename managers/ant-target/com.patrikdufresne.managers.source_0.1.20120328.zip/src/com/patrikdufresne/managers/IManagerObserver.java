package com.patrikdufresne.managers;

/**
 * This interface is used to be notify of any modification to the Manager.
 * @author patapouf
 *
 */
public interface IManagerObserver {

	public void handleManagerEvent(ManagerEvent event);
	
}
