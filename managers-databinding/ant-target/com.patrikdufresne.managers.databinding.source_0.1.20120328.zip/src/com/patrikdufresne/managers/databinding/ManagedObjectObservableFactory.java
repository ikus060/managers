/*
 * Copyright (c) 2011, Patrik Dufresne. All rights reserved.
 * Patrik Dufresne PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.patrikdufresne.managers.databinding;

import org.eclipse.core.databinding.observable.IObservable;
import org.eclipse.core.databinding.observable.masterdetail.IObservableFactory;

public class ManagedObjectObservableFactory implements IObservableFactory {

	@Override
	public IObservable createObservable(Object target) {
		
		
		
		// TODO Auto-generated method stub
		return null;
	}

}
